import { Component, OnInit } from '@angular/core';
import { Employee } from '../employee';

@Component({
  selector: 'app-template-form',
  templateUrl: './template-form.component.html',
  styleUrls: ['./template-form.component.css']
})
export class TemplateFormComponent implements OnInit {
  
  employee = new Employee();

  constructor() { }

  ngOnInit() {
  }

  submitForm(): void {
    console.log("In SUbmit Call");
  }
}
