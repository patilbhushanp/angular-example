import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-reactive-form',
  templateUrl: './reactive-form.component.html',
  styleUrls: ['./reactive-form.component.css']
})
export class ReactiveFormComponent implements OnInit {

  formGroup: FormGroup;
  formControlMap;
  formKeys = [];
  constructor(private formBuilder: FormBuilder) { 
    this.formGroup = formBuilder.group({
      "empNumberControl":  new FormControl("", []),
      "empNameControl": new FormControl("", [Validators.minLength(10), Validators.maxLength(50), Validators.required]),
      "empAddressControl": new FormControl("", []),
      "empSalaryControl": new FormControl("", [Validators.min(100), Validators.max(200), Validators.required])
    });
    this.formControlMap = this.formGroup.controls;
    this.formKeys = Object.keys(this.formControlMap);
  }

  ngOnInit() {
  }

  submitForm(): void {
    console.log(this.formControlMap);
  }
}
