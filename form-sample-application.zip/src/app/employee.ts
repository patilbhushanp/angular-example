export class Employee {
  empNumber: number;
  empName: string;
  empAddress: string;
  empSalary: number;
}
