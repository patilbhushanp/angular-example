import { Component } from '@angular/core';
import { Common } from './common';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {
  title = 'route-application';
  userName: string;

  triggerOnChange(): void {
    console.log(this.userName);
    if(this.userName && this.userName.length > 0) {
      console.log(1);
      Common.authenticated = true;
    } else {
      console.log(2);
      Common.authenticated = false;
    }
  }
}
