import { NgModule } from '@angular/core';
import { Routes, RouterModule, Router } from '@angular/router';
import { Component1Component } from './component1/component1.component';
import { Component2Component } from './component2/component2.component';
import { Component3Component } from './component3/component3.component';
import { Common } from './common';

const routes: Routes = [
  {path:"comppath1", component: Component1Component, canActivate: [Common] },
  {path:"comppath2", component: Component2Component, canActivate: [Common] },
  {path:"comppath3", component: Component3Component, canActivate: [Common] },
  // {path:"comppath4", loadChildren: () => import('./helper/helper.module') then (mod => mod.HelperModule)}
  {path:"comppath4", loadChildren: './helper/helper.module#HelperModule', canActivate: [Common]}
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {useHash: true, enableTracing: true})],
  exports: [RouterModule],
  providers: [Common]
})

export class AppRoutingModule { }
