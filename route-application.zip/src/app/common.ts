import { CanActivate } from '@angular/router';
import { ActivatedRouteSnapshot, UrlTree } from '@angular/router';
import { RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs';
export class Common implements CanActivate{

   static authenticated: boolean; 

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot)  {
        return Common.authenticated;
    }
}
