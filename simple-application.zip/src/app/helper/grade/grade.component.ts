import { Component, OnInit, Input, OnChanges, Output } from '@angular/core';
import { SimpleChanges } from "@angular/core";
import { EventEmitter } from '@angular/core';

@Component({
  selector: 'app-grade',
  templateUrl: './grade.component.html',
  styleUrls: ['./grade.component.css']
})

export class GradeComponent implements OnInit, OnChanges {
  grade: number;
  status: string;
  totalSubject = 3;

  @Input() totalMark: number = 0;
  @Output() customEvent: EventEmitter<String> = new EventEmitter<String>();

  constructor() { 
    console.log('constructor Total Mark from Mark component ' + this.totalMark); //This will not going to print 
  }

  ngOnInit() {
    console.log('ngOnInit Total Mark from Mark component ' + this.totalMark); //OnInit event.
    this.calculateGrade();
  }

  ngOnChanges(changes: SimpleChanges): void {
    console.log('ngOnInit Total Mark from Mark component ' + this.totalMark); //OnChange event from Event.
    this.calculateGrade();
  }  

  calculateGrade(): void {
    this.grade = (this.totalMark / this.totalSubject);
    if(this.grade > 45.00) {
      this.status = 'PASS';
    } else {
      this.status = 'FAIL';
    }
    this.customEvent.emit(this.status);
  }


}
