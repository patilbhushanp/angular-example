import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-marks',
  templateUrl: './marks.component.html',
  styleUrls: ['./marks.component.css']
})
export class MarksComponent implements OnInit {
  studentName: string;
  math: number;
  history: number;
  sience: number;
  totalMark: number;
  childComponentEvent: string;
  constructor() { }

  ngOnInit() {
  }

  calculateTotalMark(): number {
    this.totalMark = Number(this.math) + Number(this.history) + Number(this.sience);
    return this.totalMark;
  }

  customEventHandler(event: any): void {
    console.log(event)
    this.childComponentEvent = event;
  }

}
